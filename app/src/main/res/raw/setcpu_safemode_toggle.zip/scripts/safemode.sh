#!/sbin/sh
if [ -f "/data/local/setcpu_safemode" ] ; then
	rm -r /data/local/setcpu_safemode
else
	if [ ! -d "/data/local" ] ; then
		mkdir /data/local
	fi
	echo '' > /data/local/setcpu_safemode
	chmod 666 /data/local/setcpu_safemode
fi